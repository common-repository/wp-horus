<?php
/*
Plugin Name: wp-hoRus
Plugin URI: http://
Description: Добавляет виджет "Гороскоп".
Version: 0.1
Author: Andrey Ershov
Author URI: http://
*/
/*  Copyright 2011  Andrey Ershov  (email: kgx@ukr.net)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

function horus_widget($args) {
    extract($args);                                  //Получение аргументов
    $data['title']=get_option('horus_widget_title'); //Получаем заголовок
    $data['theme']=get_option('horus_widget_theme'); //Получаем выбранную тему
    $data['sizes']=get_option('horus_widget_sizes'); //Получаем размеры
	$data['style']=get_option('horus_widget_style'); //Получаем стили пользователя
	
    echo $before_widget;                       // --> начало вывода виджета
    echo $before_title;                            // --> начало вывода заголовка виджета
    echo (empty($data['title'])? '' : $data['title']); //Вывод заголовка виджета
    echo $after_title;                               // --> конец вывода заголовка виджета
	echo '<div id="horo_emotion" style="', $data['style'], '">Loading...</div>
	<!-- Разместить перед тегом </body> -->
	<script type="text/javascript" src="http://informers.ukr.net/horo/emotion/js.php?Type=', $data['theme'], '&Size=', $data['sizes'], '&div=horo_emotion" charset="windows-1251"></script>';
	
	//echo '<div style="', $data['style'], '"><ul><object width="', $data['width'], '" height="', $data['height'], '" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0"><param name="src" value="', $data['link'], '&hl=en&fs=1&rel=0&border=0"><embed type="application/x-shockwave-flash" width="', $data['width'], '" height="', $data['height'], '"allowfullscreen="true" src="', $data['link'], '&hl=en&fs=1&rel=0&border=0"> </embed></object></ul></div>';            // --> вывод видеоролика
    echo $after_widget;                          // --> конец вывода виджета
}
function horus_widget_control() {
	$themes = array('Гламур'=>'glamour', 'Гламур2'=>'glamour2', 'Эмо'=>'emo', 'Липтон'=>'lipton', 'Минимал'=>'minimal', 'Солнечный'=>'sunny');
	$sizes = array('200x300', '200x350', '300x300', '240x350', '240x400');
	
    if (isset($_REQUEST['horus_widget_title'])) { 
        update_option('horus_widget_title', $_REQUEST['horus_widget_title']);       //Обновляем заголовок виджета
    }
	if (!empty($_REQUEST['horus_widget_theme'])) { 
        update_option('horus_widget_theme', $_REQUEST['horus_widget_theme']);       //Обновляем тему
	}
	if (!empty($_REQUEST['horus_widget_sizes'])) { 
        update_option('horus_widget_sizes', $_REQUEST['horus_widget_sizes']);       //Обновляем ширину блока
	}
    update_option('horus_widget_style', $_REQUEST['horus_widget_style']);       //Обновляем стили блока
 /* Выводим элементы управления */
	echo 'Заголовок виджета:<br>
<input style="width:220px;" type="text" name="horus_widget_title" value="'.get_option('horus_widget_title').'" /><br />'; //Настройки заголовка виджета

	echo 'Выберите тип дизайна:<br>
	<select name="horus_widget_theme">'; // Выбор типа дизайна
		$selected = get_option('horus_widget_theme');
		foreach ( $themes as  $key => $value) {
			echo '<option value="' . esc_attr( $value ) . '"';
			if($value == $selected) { echo ' selected="selected"'; }
			echo '>' . esc_html( $key ) . "</option>\n";
		}
	echo '</select><br />';

	echo 'Размер блока:<br>
	<select name="horus_widget_sizes">'; // Выбор типа дизайна
		$selected = get_option('horus_widget_sizes');
		foreach ( $sizes as  $value) {
			echo '<option value="' . esc_attr( $value ) . '"';
			if($value == $selected) { echo ' selected="selected"'; }
			echo '>' . esc_html( $value ) . "</option>\n";
		}
	echo '</select><br />';

	echo 'Атрибут style:<br>
<input style="width: 220px;" type="text" name="horus_widget_style" value="'.get_option('horus_widget_style').'" /><br />'; //Поле для ввода стилей

}
   register_sidebar_widget('hoRus', 'horus_widget'); //регистрируем виджет
   register_widget_control('hoRus', 'horus_widget_control' ); //регистрируем элемент управления виджетом
?>