=== hoRus ===
Contributors: yorsh
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=kgx%40ukr%2enet
Tags: php, widget, horoscope
Requires at least: 0.1
Tested up to: 0.1
Stable tag: 0.1

== Description ==

This widget displays the horoscope.
You can choose the style and size.


== Installation ==

1. Upload `wp-horo.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the widget like any other widget.